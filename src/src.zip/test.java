import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeMap;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String x = "P(B=true|J=true,M=true),1";
		String[] y = x.split("[|]");
		System.out.println(y[0]+" "+y[1]);
		String[] VarAndVal = (y[0].substring(2)).split("=");
		System.out.println(VarAndVal[0]+" "+VarAndVal[1]);
		String z[]=y[1].split(","),type=z[z.length-1];
		z = Arrays.copyOf(z, z.length-1);
		System.out.println(z[0]+','+z[1]);*/
		
		
		/*String xyz = "XYZ";
		System.out.println(xyz.substring(0,xyz.length()-1));
		TreeMap<String,Double> CPT= new TreeMap<>();
		CPT.put("true,true,true", 0.95);
		CPT.put("true,true,false", 0.05);
		CPT.put("true,false,true", 0.94);
		CPT.put("true,false,false", 0.06);
		CPT.put("false,true,true", 0.29);
		CPT.put("false,true,false", 0.71);
		CPT.put("false,false,true", 0.001);
		CPT.put("false,false,false", 0.999);
		String ans = "";
		ans = Arrays.toString(CPT.keySet().toArray());
		ans+="\n values: "+Arrays.toString(CPT.values().toArray());
		System.out.println(ans);*/
		
		/*Variable b = new Variable("X");
		Variable c = new Variable("X");
		System.out.println(b.equals(c));*/
		
		
	}

}
