import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BayesianNetwork {

	private List<Variable> varsNetwork;//** Mapping a name to it's Variable
	
	public BayesianNetwork() {
		varsNetwork = new ArrayList<>();
	}
	
	public List<Variable> getCopyOfBNTK(){
		return new ArrayList<>(varsNetwork);
	}
	
	public void AddVariable(Variable var) {
		varsNetwork.add(var);
	}
	public void ReplaceVariable(Variable var) {
		int ind = varsNetwork.indexOf(var);
		if(ind == -1)
			varsNetwork.add(var);
		else {
			varsNetwork.remove(var);
			varsNetwork.add(ind,var);
		}
	}
	
	public Variable varAt(int i) {
		if(i<varsNetwork.size())
			return varsNetwork.get(i);
		return null;
	}
	
	public int indexOf(Variable var) {
		return varsNetwork.indexOf(var);
	}
	
	public int size() {
		return varsNetwork.size();
	}
	
	public Variable getVarByName(String name) {
		for(Variable var:varsNetwork) {
			if(var.getName().equals(name))
				return var;
		}
		return null;
	}
	
	public String toString() {
		return Arrays.toString(varsNetwork.toArray());
	}

	public void OrderObservedVariablesAndEvi(List<Variable> observedVars, List<String> evidence) {
		List<Variable> tmpObs = new ArrayList<>();
		List<String> tmpEvi = new ArrayList<>();
		for (int i = 0; i < varsNetwork.size(); i++) {
			Variable var = varsNetwork.get(i);
			int indx = -1;
			if((indx = observedVars.indexOf(var)) != -1) {
				tmpObs.add(var);
				tmpEvi.add(evidence.get(indx));
			}
		}
		observedVars = tmpObs;
		evidence = tmpEvi;
	}

	public List<Variable> getHidden(List<Variable> obeservedVar) {
		List<Variable> hidden = new ArrayList<>();
		for(Variable var:varsNetwork)
			if(!obeservedVar.contains(var))
				hidden.add(var);
		return hidden;
	}

	public BayesianNetwork eliminateVariables(Variable var, List<Variable> obeservedVar, List<String> evidence) {
		BayesianNetwork ans = new BayesianNetwork();
		List<String> nameOfVarParents = new ArrayList<>();
		List<Variable> maxDepthsVars = new ArrayList<>();
		maxDepthsVars.add(var);
		int max = var.depth(),min = max;
		for(Variable tmp:obeservedVar) {
			int tmpDepth = tmp.depth();
			if(max < tmpDepth) {
				maxDepthsVars = new ArrayList<>();
				maxDepthsVars.add(tmp);
				max = tmpDepth;
			}
			else if(max == tmpDepth) {
				maxDepthsVars.add(tmp);
			}
			else if(min > tmpDepth) {
				min = tmpDepth;
			}
		}
		for(Variable v:maxDepthsVars) {
			nameOfVarParents.add(v.getName());
			getNamesOfParentsOf(v,nameOfVarParents);
		}
		for(Variable v : varsNetwork) {
			if(nameOfVarParents.contains(v.getName()))
				ans.AddVariable(v);
		}
		return ans;
	}
	/**
	 * Yields a new network where only the deepest observed variable(s) and its parents are kept.
	 * @param var
	 * @param nameOfVarParents new network  where only the relevant variable are kept
	 */
	private void getNamesOfParentsOf(Variable var, List<String> nameOfVarParents) {
		List<Variable> paretns = var.getParents();
		if(paretns!=null)
			for(Variable par : paretns) {
				String Name = par.getName();
				if(!nameOfVarParents.contains(Name)) {
					nameOfVarParents.add(Name);
					getNamesOfParentsOf(par, nameOfVarParents);
				}
			}
	}

}
