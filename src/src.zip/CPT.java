import java.util.TreeMap;

public class CPT<K,V> extends TreeMap {
	private String[] parents;
	
}
