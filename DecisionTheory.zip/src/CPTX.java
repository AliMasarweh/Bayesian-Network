import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class CPTX {
	
	private List<String> namesOfHIdden;
	private Map<String,Double> cptOfHidden;
	private final String notObserved = "Not_Observed";
	
	public List<String> getNamesOfHIdden() {
		return namesOfHIdden;
	}

	public Map<String, Double> getCptOfHidden() {
		return cptOfHidden;
	}
	
	public boolean containsHiddenName(String Name) {
		return namesOfHIdden.contains(Name);
	}
	
	private CPTX() {
		namesOfHIdden = new ArrayList<>();
		cptOfHidden = new TreeMap<>();
	}
	
	public CPTX(Variable A,List<Variable> observedVars,List<String> evidence) {
		namesOfHIdden = new ArrayList<>();
		cptOfHidden = new TreeMap<>();
		fill(A,observedVars,evidence);
	}
	
	
	private void fill(Variable A, List<Variable> observedVars, List<String> evidence) {
		List<String> EviList = new ArrayList<>();
		List<Variable> ListOfParents = A.getParents();
		
		ListOfVarsAndThierValues(A,observedVars,evidence,ListOfParents,EviList);
		
		//Key without the observed variables. Initiating each CPT with observed variables
		cptWithKeysOfHidden(A,ListOfParents,EviList);
		
	}
	
	/**
	 * 
	 * @param A
	 * @param listOfParents
	 * @param EviList
	 */
	private void cptWithKeysOfHidden(Variable A, List<Variable> listOfParents, List<String> EviList) {
		String newKey = "";
		TreeMap<String,Double> ACPT = A.getCPT();
		Set<String> keys = ACPT.keySet();
		for(String key : keys) {
			String[] SplitedK = key.split(",");
			boolean flag = false;
			newKey = "";
			for (int i = 0; i < SplitedK.length; i++) {
				if(!EviList.get(i).equals(notObserved)) {
					if(!EviList.get(i).equals(SplitedK[i])) {
						flag = true;
						break;
						}
				}
				else
				{
					//Save the hidden variables values
					newKey += SplitedK[i] + ",";
				}
			}
			if(!flag) {
				newKey = newKey.substring(0, newKey.length()-1);
				// *** In case complier doesn't work with lambda ***
				/*if(cptOfHidden.get(newKey) == null)cptOfHidden.put(newKey, ACPT.get(key));
				else {
					double tmp = cptOfHidden.remove(newKey);
					cptOfHidden.put(newKey, tmp + ACPT.get(key));
				}*/
				
				//cptOfHidden.computeIfPresent(newKey, (K,V) -> V+ACPT.get(key));
				cptOfHidden.put(newKey, ACPT.get(key));
			}
		}
	}

	/**
	 * 
	 * @param A
	 * @param observedVars
	 * @param evidence
	 * @param ListOfParents
	 * @param EviList
	 */
	private void ListOfVarsAndThierValues(Variable A, List<Variable> observedVars, List<String> evidence,
			List<Variable> ListOfParents, List<String> EviList) {
		if(ListOfParents != null)
			for(Variable v : ListOfParents) {
				if(!observedVars.contains(v)) {
					namesOfHIdden.add(v.getName());
					EviList.add(notObserved);
				}
				else
					EviList.add(evidence.get(observedVars.indexOf(v)));
			}
		if(!observedVars.contains(A)) {
			namesOfHIdden.add(A.getName());
			EviList.add(notObserved);
		}
		else
			EviList.add(evidence.get(observedVars.indexOf(A)));
	}

	
	public CPTX CartazineProduct(CPTX o, List<String> MutualVars, int[] operationsC) {
		List<Integer> IndexOfMutualInThis = new ArrayList<>(),IndexOfMutualInO = new ArrayList<>();
		//
		this.getMutual(o, MutualVars, IndexOfMutualInThis, IndexOfMutualInO);
		return joinCPTX(o,MutualVars,IndexOfMutualInThis,IndexOfMutualInO,operationsC);
		
	}
	
	private CPTX joinCPTX(CPTX o, List<String> mutualVars, List<Integer> indexOfMutualInThis,
			List<Integer> indexOfMutualInO, int[] operationsC) {
		CPTX ans = new CPTX();
		ans.namesOfHIdden = new ArrayList<>(this.namesOfHIdden);
		for(String namesOfHid : o.namesOfHIdden) {
			if(!ans.namesOfHIdden.contains(namesOfHid))
				ans.namesOfHIdden.add(namesOfHid);
		}
		/***
		 * **** check if you are joining on the same no hidden
		 */
		boolean flag = false;
		Set<String> KeySetThis = cptOfHidden.keySet(), KeySetO = o.cptOfHidden.keySet();
		for(String KeyThis : KeySetThis) {
			String[] SKThis = KeyThis.split(",");
			for(String KeyO : KeySetO) {
				flag = false;
				String[] SKO =KeyO.split(",");
				List<Integer> tmpIndexsT = new ArrayList<>(indexOfMutualInThis), 
						tmpIndexsO = new ArrayList<>(indexOfMutualInO);
				// If there's no mutual tmpIndexsT will be empty.
				while(!flag && !tmpIndexsT.isEmpty() && !tmpIndexsO.isEmpty()) {
					//If the mutual values are not the same, don't join.
					if(!SKThis[tmpIndexsT.remove(0)].equals(SKO[tmpIndexsO.remove(0)]))
						flag = true;
				}
				if(!flag) {
					double jointComputation = this.cptOfHidden.get(KeyThis)*o.cptOfHidden.get(KeyO);
					operationsC[1]++;
					// *** In case complier doesn't work with lambda ***
					/*if(ans.cptOfHidden.get(KeyThis) == null) ans.cptOfHidden.put(KeyThis, jointComputation);
					else {
						double tmp = ans.cptOfHidden.remove(KeyThis);
						ans.cptOfHidden.put(KeyThis, jointComputation + tmp);
					}*/
					//ans.cptOfHidden.computeIfPresent(Union(KeyThis,KeyO), (K,V) -> V + jointComputation);
					ans.cptOfHidden.put(Union(KeyThis,KeyO,indexOfMutualInO), jointComputation);
				}
			}
		}
		return ans;
	}

	private String Union(String keyThis, String keyO, List<Integer> indexOfMutualInO) {
		String ans = keyThis;
		String tmp = "";
		int i = 0,j = 0;
		String[] spliteKey = keyO.split(",");
		while(!indexOfMutualInO.isEmpty()) {
			j = indexOfMutualInO.remove(0);
			for (; i < j; i++) {
				tmp = tmp + spliteKey[i] + ",";
			}
			i = j+1;
		}
		for(;i < spliteKey.length; i++)
			tmp = tmp + spliteKey[i] + ",";
		if(tmp.length() > 0 && tmp.charAt(tmp.length()-1)==',')
			tmp = tmp.substring(0,tmp.length()-1);
		tmp = tmp.length()>0?"," + tmp: "";
		return ans + tmp;
	}

	public void getMutual(CPTX o, List<String> MutualVars, List<Integer> IndexOfMutualInThis ,List<Integer> IndexOfMutualInO) {
		for (String name : this.namesOfHIdden) {
			for(String nameO : o.namesOfHIdden) {
				if(name.equals(nameO)) {
					MutualVars.add(name);
					IndexOfMutualInThis.add(this.namesOfHIdden.indexOf(name));
					IndexOfMutualInO.add(o.namesOfHIdden.indexOf(nameO));
					break;
				}
			}
		}
		
	}

	public void eliminateHidden(List<CPTX> Fcpt,List<String> MutualVars, int[] operationsC) {
		List<Boolean> foundMoreHidden = new ArrayList<>();
		CreateListOf_isThereMoreOfHidden(Fcpt,MutualVars,foundMoreHidden);
		eliminateNonFoundedHidden(Fcpt,MutualVars,foundMoreHidden,operationsC);
		
	}

	private void eliminateNonFoundedHidden(List<CPTX> fcpt, List<String> mutualVars, List<Boolean> foundMoreHidden,
			int[] operationsC) {
		for(boolean foundedHidden : foundMoreHidden) {
			if(!foundedHidden) {
				String eliminateVarName = mutualVars.get(foundMoreHidden.indexOf(foundedHidden));
				int indexOfEliminated = namesOfHIdden.indexOf(eliminateVarName);
				Set<String> keys = cptOfHidden.keySet();
				TreeMap<String,Double> newCpt = new TreeMap<>();
				for(String key : keys) {
					String[] splitedKey = key.split(",");
					String tmp = "";
					for (int i = 0; i < splitedKey.length; i++) {
						if(i!=indexOfEliminated)
							tmp += splitedKey[i] + ",";
					}
					tmp = tmp.substring(0,tmp.length()-1);
					double prob = cptOfHidden.get(key);
					//if lambda doesn't complie
					/*if(newCpt.get(tmp) == null) newCpt.put(tmp, prob);
					else{
						operationsC[0]++;
						newCpt.put(tmp, newCpt.remove(tmp) + prob);
						}*/
					operationsC[0]++;
					if(newCpt.computeIfPresent(tmp, (K,V) -> V+prob) == null) operationsC[0]--;
					newCpt.computeIfAbsent(tmp, (K) -> prob);
				}
				this.namesOfHIdden.remove(foundMoreHidden.indexOf(foundedHidden));
				this.cptOfHidden = newCpt;
			}
		}
	}

	private void CreateListOf_isThereMoreOfHidden(List<CPTX> fcpt, List<String> MutualVars, List<Boolean> foundMoreHidden) {
		boolean foundAHidden = false;
		for (int j = fcpt.size()-1; j >= 0; j--) {
			foundAHidden = false;
			for(String Name : MutualVars) {
				if(foundAHidden =fcpt.get(j).containsHiddenName(Name)) {
					//found more of the variable
					foundMoreHidden.add(true);
					break;
				}
				if(!foundAHidden)
					foundMoreHidden.add(true);
			}
		}
	}
	
	public String toString() {
		String ans = "";
		ans = "Names of Hidden: " + this.namesOfHIdden.toString();
		ans += "Cpt keys: " + this.cptOfHidden.keySet().toString();
		ans += "Cpt pro: " + this.cptOfHidden.values().toString();
		return ans;
	}

}
