
public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputFileProcessor IFP = new InputFileProcessor();
		IFP.ProcessFile("input.txt");
		IFP.processQueries();
	}

}
