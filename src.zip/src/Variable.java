import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Variable{
	
	private String Name;
	private List<String> Values;
	private List<Variable> Parents;
	private Map<String,Double> CPT;//** Hashed sequence of evidence
	
	
	/* ***Constructors*** */
	public Variable(String name) {
		Name = name;
		Values = new ArrayList<>();
		Parents = new ArrayList<>();
		CPT = new TreeMap<>(Collections.reverseOrder());
	}
	
	
	/* ***Methods*** */
	
	public Variable getParent(int i) {
		return (Parents == null?null:Parents.get(i));
	}
	
	public int parentAt(Variable parent) {
		return Parents.indexOf(parent);
	}
	
	public String getName() {
		return Name;
	}
	
	public ArrayList<String> getValues(){
		return new ArrayList<>(Values);
	}
	
	public ArrayList<Variable> getParents(){
		return (Parents!=null)? new ArrayList<>(Parents): null;
	}
	
	private String parentsNames(){
		String ans = new String("[");
		for(Variable par:Parents)
			ans += par.getName()+",";
		ans = ans.substring(0, ans.length()-1) +"]";
		return ans;
	}
	public TreeMap<String,Double> getCPT(){
		return new TreeMap<>(CPT);
	}

	public void AddValues(List<String> values) {
		Values = new ArrayList<>(values.size());
		for(String val:values) {
			Values.add(val.substring(1));
		}
	}
	
	public void AddParents(List<Variable> parents) {
		Parents = (parents != null)? new ArrayList<>(parents):null;
	}
	
	int numOfValues() {
		return this.Values.size();
	}
	
	public void AddToCPT(String sequenceValuesHashed,Double probability) {
		CPT.put(sequenceValuesHashed, probability);
	}
	
	public int depth() {
		if(Parents == null)
			return 0;
		int max = 0;
		for(Variable par:Parents)
			max = Math.max(max, par.depth()+1);
		return max;
	}
	
	public boolean isParentOf(Variable var) {
		if(var.Parents == null) return false;
		if(var.Parents.contains(this)) return true;
		for(Variable par:var.Parents)
			if(this.isParentOf(par))
				return true;
		return false;
	}
	
	/**
	 * 
	 * @param network
	 * @param evidence
	 * @param operationsC
	 * @return
	 */
	private static double CalculateProbForObservedNetwork(BayesianNetwork network,List<Variable> obeservedVar,List<String> evidence,int[] operationsC) {
		double ans = 1;String eviOfVar = "";double prob=0;
		for (int indexOfVar = 0; indexOfVar < network.size(); indexOfVar++) {
			Variable var = network.varAt(indexOfVar);
			if(var.Parents == null || var.Parents.isEmpty()) {
				eviOfVar = evidence.get(obeservedVar.indexOf(var));
				prob = var.CPT.get(eviOfVar);
				operationsC[1]++;
				ans*=prob;
			}
			else {
				String conditionalProb = "";
				for (int i = 0; i < var.Parents.size(); i++) {
					Variable par = var.Parents.get(i);
					String eviOfPar = evidence.get(obeservedVar.indexOf(par));
					conditionalProb += eviOfPar +",";
				}
				eviOfVar = evidence.get(obeservedVar.indexOf(var));
				conditionalProb += eviOfVar;
				prob = var.CPT.get(conditionalProb);
				operationsC[1]++;
				ans *= prob;
			}
		}
		return ans;
	}
	
	private static double ObserveHiddenVars(BayesianNetwork network,List<Variable> obeservedVar,
			List<String> evidence,int[] operationsC,int i,int append) {
		if(i==network.size()) {
			operationsC[1]--;
			return CalculateProbForObservedNetwork(network, obeservedVar, evidence, operationsC);
		}
		Variable var = network.varAt(i);
		if(obeservedVar.contains(var)) {
			return ObserveHiddenVars(network, obeservedVar, evidence, operationsC, i+1,append);
		}
		double sum = 0;
		List<String> vals = var.Values;
		operationsC[0] += var.numOfValues()-1;
		obeservedVar.add(append,var);
		for(String val : vals) {
			evidence.add(append,val);
			sum += ObserveHiddenVars(network, obeservedVar, evidence, operationsC, i+1,append+1);
			evidence.remove(append);
		}
		obeservedVar.remove(append);
		return sum;
	}
	
	public static double probabilityOfNoFactoring(BayesianNetwork network,Variable var,List<Variable> obeservedVar,
			List<String> evidence,int[] operationsC) {
		double sumForVal = 0,sumForOther = 0;
		sumForVal = ObserveHiddenVars(network, obeservedVar, evidence, operationsC, 0,obeservedVar.size());
		String Value = evidence.remove(0);
		for(String val:var.Values) {
			if(!Value.equals(val)) {
				evidence.add(0,val);
				double tmp = ObserveHiddenVars(network, obeservedVar, evidence, operationsC, 0, obeservedVar.size());
				sumForOther += tmp;
				evidence.remove(0);
			}
		}
		operationsC[0]++;
		double alpha = 1.0/(sumForVal+sumForOther)*100000.0;
		return Math.round(sumForVal*alpha)/100000.0;
	}
	
	private double probOf(List<Variable> obeservedVar,List<String> evidence,int[] operationsC) {
		double ans = 1;
		String eviOfThis = evidence.get(obeservedVar.indexOf(this));
		if(this.Parents == null)
			ans = this.CPT.get(eviOfThis);
		else {
			String conditionEvi = "";
			for (int i = 0; i < this.Parents.size(); i++) {
				Variable par = this.Parents.get(i);
				String eviOfPar = evidence.get(obeservedVar.indexOf(par));
				conditionEvi += eviOfPar +",";
			}
			conditionEvi += eviOfThis;
			ans = this.CPT.get(conditionEvi);
		}
		return ans;
	}
	
	private static double ObserveHiddenVarsFac(BayesianNetwork network,List<Variable> obeservedVar,
			List<String> evidence,int[] operationsC,int i,int append) {
		if(i==network.size()) {
			operationsC[1]--;
			return 1;
		}
		Variable var = network.varAt(i);
		if(obeservedVar.contains(var)) {
			operationsC[1]++;
			return var.probOf(obeservedVar, evidence, operationsC)*ObserveHiddenVarsFac(network, obeservedVar, evidence, operationsC, i+1,append);
		}
		double sum = 0;
		List<String> vals = var.Values;
		obeservedVar.add(append,var);
		for(String val : vals) {
			evidence.add(append,val);
			sum += var.probOf(obeservedVar, evidence, operationsC)*ObserveHiddenVarsFac(network, obeservedVar, evidence, operationsC, i+1,append+1);
			operationsC[1]++;
			operationsC[0]++;
			evidence.remove(append);
		}
		obeservedVar.remove(append);
		operationsC[0]--;
		return sum;
	}	
	
	public static double probabilityWithFactoring(BayesianNetwork network,Variable var,List<Variable> obeservedVar,
			List<String> evidence,int[] operationsC) {
		BayesianNetwork tmpNetwork = network.eliminateVariables(var,obeservedVar,evidence);
		double sumForVal = 0,sumForOther = 0;
		sumForVal = ObserveHiddenVarsFac(tmpNetwork, obeservedVar, evidence, operationsC, 0,obeservedVar.size());
		String Value = evidence.remove(0);
		for(String val:var.Values) {
			if(!Value.equals(val)) {
				evidence.add(0,val);
				double tmp = ObserveHiddenVarsFac(network, obeservedVar, evidence, operationsC, 0, obeservedVar.size());
				sumForOther += tmp;
				evidence.remove(0);
			}
		}
		operationsC[0]++;
		double alpha = 1.0/(sumForVal+sumForOther)*100000.0;
		return Math.round(sumForVal*alpha)/100000.0;
	}
	
	
	
	public static TreeMap<String,Double> varEli(BayesianNetwork network,Variable v,String value, List<Variable> obeservedVar,
			List<String> evidence,int[] operationsC,int i ,int append) {
		TreeMap<String,Double> ans = new TreeMap<>();
		Variable x = network.varAt(i);
		/*
		 * Create table for variable i
		 * if x is(equals) var create for every value
		 * if x is Hidden create also create table for every possible value 
		 * and parents observed values(if any).
		 */
		if(i>=network.size()) {
			
			varEli(network, v, value, obeservedVar, evidence, operationsC, i+1, append);
		}
		/*
		 * Process table and return
		 */
		return ans;
	}
	
	


	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(obj instanceof Variable) {
			return this.Name.equals(((Variable) obj).Name);
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String ans = "Name: "+this.Name +"\n Values: "+Arrays.toString(Values.toArray())+"\n Parents: ";
		ans+=(Parents==null?null:parentsNames())+"\n CPT:\n keys: "+Arrays.toString(CPT.keySet().toArray());
		ans+="\n values: "+Arrays.toString(CPT.values().toArray());
		return ans;
	}
}
