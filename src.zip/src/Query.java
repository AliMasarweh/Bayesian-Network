import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Query {
	
	private BayesianNetwork BTN;
	private Variable Var;
	private String Value;
	private List<Variable> ObservedVars;
	private List<String> Evidence;
	private String Type;

	public Query(BayesianNetwork BNTK,Variable variable,String value,List<Variable> observedVars,
			List<String> evidence, String type) {
		// TODO Auto-generated constructor stub
		BTN=BNTK;
		Var=variable;
		Value = new String(value);
		this.ObservedVars = new ArrayList<>(observedVars);
		this.Evidence = new ArrayList<>(evidence);
		Type = new String(type);
	}
	public double process(int[] operationsCount) {
		// TODO Auto-generated method stub
		double ans = 1;
		if(Type.equals("1")) {
			ObservedVars.add(0, Var);
			Evidence.add(0,Value);
			return Variable.probabilityOfNoFactoring(BTN,Var, ObservedVars, Evidence, operationsCount);
		}
		else if(Type.equals("2")) {
			ObservedVars.add(0, Var);
			Evidence.add(0,Value);
			return Variable.probabilityWithFactoring(BTN,Var, ObservedVars, Evidence, operationsCount);
		}
		else if(Type.equals("3")) {
			return -1234321;
		}
		return ans;
	}

	public String toString() {
		String ans = new String("P(");
		ans += Var.getName() +"="+ Value +"|";
		for (int i = 0; i < ObservedVars.size(); i++) {
			ans+=ObservedVars.get(i).getName() +"="+ Evidence.get(i)+",";
		}
		ans = ans.substring(0, ans.length()-1) + "),"+Type;
		return ans;
	}
}
