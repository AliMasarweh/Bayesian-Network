import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class InputFileProcessor {
	
	private BayesianNetwork BNT;
	private List<Query> queriesList;
	
	public void ProcessFile(String FileName) {
		BufferedReader buffInFlReader = null;
		List<String> VariablesData = null,QueriesData = null;
		try {
			buffInFlReader = new BufferedReader(new FileReader(FileName));
			VariablesData = DataOfVariablesOrQueries(buffInFlReader);
			QueriesData = DataOfVariablesOrQueries(buffInFlReader);
			buffInFlReader.close();
			BuildBayesianNetwork(VariablesData);
			BuildQueriesList(QueriesData);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	private List<String> DataOfVariablesOrQueries(BufferedReader buffInFlReader) throws IOException{
		List<String> ans = new ArrayList<>();
		String Line = buffInFlReader.readLine();
		while( Line != null && !Line.equals("Queries")) {
			ans.add(Line);
			Line = buffInFlReader.readLine();
		}
		return ans;
	}
	
	private void BuildBayesianNetwork(List<String> VariablesData) throws Exception{
		BNT = BayesianNetworkFactory.BuildBayesNetwork(VariablesData);
	}
	
	private void BuildQueriesList(List<String> QueriesData) throws Exception {
		queriesList = QueriesFactory.BuildQueries(BNT,QueriesData);
	}
	
	public void processQueries() {
		int[] operationsCount = new int[2];
		File output = new File("output.txt");
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(output);
			for(Query query:queriesList) {
				operationsCount[0] = 0;
				operationsCount[1] = 0;
				double ans = query.process(operationsCount);
				pw.print(ans+","+operationsCount[0]+","+operationsCount[1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pw.close();
	}

}
